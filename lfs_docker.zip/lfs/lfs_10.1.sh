#!/bin/bash
NBD=nbd1
# change the source 
cat >/etc/apt/sources.list <<"EOF"
deb http://mirrors.aliyun.com/ubuntu/ xenial main
deb-src http://mirrors.aliyun.com/ubuntu/ xenial main

deb http://mirrors.aliyun.com/ubuntu/ xenial-updates main
deb-src http://mirrors.aliyun.com/ubuntu/ xenial-updates main

deb http://mirrors.aliyun.com/ubuntu/ xenial universe
deb-src http://mirrors.aliyun.com/ubuntu/ xenial universe
deb http://mirrors.aliyun.com/ubuntu/ xenial-updates universe
deb-src http://mirrors.aliyun.com/ubuntu/ xenial-updates universe

deb http://mirrors.aliyun.com/ubuntu/ xenial-security main
deb-src http://mirrors.aliyun.com/ubuntu/ xenial-security main
deb http://mirrors.aliyun.com/ubuntu/ xenial-security universe
deb-src http://mirrors.aliyun.com/ubuntu/ xenial-security universe
EOF
# install tool to prepare the base environment
apt-get update
apt-get install -y kmod qemu-utils wget xz-utils
apt-get install -y grub
apt-get install -y grub2
apt-get install -y build-essential libssl-dev bzip2 pkg-config intltool flex bc libelf-dev
#apt-get install -y parted
#create virtual disk(vdi format)
cd vdisk
##qemu-img  create -f vdi lfs_10.1.vdi 500M
qemu-img  create -f qcow2 lfs_10.1.qcow2 500M
cd ../ 

# setpu network block device
modprobe nbd
partprobe
# nbd connect the virtual disk
##qemu-nbd -c /dev/nbd0 ./vdisk/lfs_10.1.vdi
qemu-nbd -c /dev/$NBD ./vdisk/lfs_10.1.qcow2

# check the virtual disk
partprobe
fdisk -l


# Make the LFS
# Part II. Preparing for the Build

# 2.2. Host System Requirements
apt-get install -y bison gawk gcc g++ m4 make patch python3 texinfo

# 2.4. Creating a New Partition
# Create Partition lfs and swap
fdisk /dev/$NBD << EOF
n
p
1

+400M
w
EOF
sync
partprobe
# 2.5. Creating a File System on the Partition
mkfs -t ext4 /dev/${NBD}p1


export LFS=/mnt/lfs
# 2.7. Mounting the New Partition
partprobe
mkdir -pv $LFS
mount -v -t ext4 /dev/${NBD}p1 $LFS
sync
df -h
# Chapter 4. Final Preparations
# 4.2. Creating a limited directory layout in LFS filesystem
mkdir -pv $LFS/{bin,etc,lib,sbin,usr,var}
case $(uname -m) in
  x86_64) mkdir -pv $LFS/lib64 ;;
esac
mkdir -pv $LFS/tools

# Part III. Building the LFS Cross Toolchain and Temporary Tools
# install and use the mwget
# 多线程下载工具
cd /jin/sources
wget http://jaist.dl.sourceforge.net/project/kmphpfm/mwget/0.1/mwget_0.1.0.orig.tar.bz2
tar -xjvf mwget_0.1.0.orig.tar.bz2
cd mwget_0.1.0.orig
./configure --prefix=$LFS/tools
make
make install
rm -r mwget_0.1.0.orig
##install gcc-9
apt install software-properties-common -y
add-apt-repository ppa:ubuntu-toolchain-r/test -y
apt-get update -y
apt install gcc-9 g++-9 -y
update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-9 60 --slave /usr/bin/g++ g++ /usr/bin/g++-9
# Setting The $LFS Variable

#set +h

umask 022
LFS=/mnt/lfs
LC_ALL=POSIX
LFS_TGT=
##LFS_TGT=$(uname -m)-lfs-linux-gnu
PATH=/usr/bin:/sbin:/usr/sbin
if [ ! -L /bin ]; then PATH=/bin:$PATH; fi
PATH=$LFS/tools/bin:$PATH
CONFIG_SITE=$LFS/usr/share/config.site
export LFS LC_ALL LFS_TGT PATH CONFIG_SITE
#lfs_10.1包
cd /jin/sources
#mwget ftp://ftp.osuosl.org/pub/lfs/lfs-packages/lfs-packages-10.1.tar
mkdir -pv /jin/sources/10.1
#mwget http://mirror.jaleco.com/lfs/pub/lfs/lfs-packages/lfs-packages-10.1.tar
#tar -xvf lfs-packages-10.1.tar

#install linux header
cd /jin/sources/10.1
mkdir -pv /jin/sources/10.1
#mwget ftp://ftp.osuosl.org/pub/lfs/lfs-packages/10.1/linux-5.10.17.tar.xz
mwget http://mirror.jaleco.com/lfs/pub/lfs/lfs-packages/10.1/linux-5.10.17.tar.xz
tar -xvf linux-5.10.17.tar.xz
cd linux-5.10.17
make mrproper
make headers
find usr/include -name '.*' -delete
rm usr/include/Makefile
cp -rv usr/include $LFS/usr

#install  glibc-2.33
cd /jin/sources/10.1
#mwget ftp://ftp.osuosl.org/pub/lfs/lfs-packages/10.1/glibc-2.33.tar.xz
#mwget ftp://ftp.osuosl.org/pub/lfs/lfs-packages/10.1/glibc-2.33-fhs-1.patch
mwget http://mirror.jaleco.com/lfs/pub/lfs/lfs-packages/10.1/glibc-2.33.tar.xz
mwget http://mirror.jaleco.com/lfs/pub/lfs/lfs-packages/10.1/glibc-2.33-fhs-1.patch
tar -xvf glibc-2.33.tar.xz
cd glibc-2.33 
case $(uname -m) in
    i?86)   ln -sfv ld-linux.so.2 $LFS/lib/ld-lsb.so.3
    ;;
    x86_64) ln -sfv ../lib/ld-linux-x86-64.so.2 $LFS/lib64
            ln -sfv ../lib/ld-linux-x86-64.so.2 $LFS/lib64/ld-lsb-x86-64.so.3
    ;;
esac
patch -Np1 -i ../glibc-2.33-fhs-1.patch
mkdir -v build
cd       build
../configure                             \
      --prefix=/usr                      \
      --host=$LFS_TGT                    \
      --build=$(../scripts/config.guess) \
      --enable-kernel=3.2                \
      --with-headers=$LFS/usr/include    \
      libc_cv_slibdir=/lib		 \
      --disable-timezone-tools  --disable-profile  --disable-mathvec --disable-werror --disable-crypt
make 
make DESTDIR=$LFS install

###########################

#install coreutil
cd /jin/sources/10.1
#mwget ftp://ftp.osuosl.org/pub/lfs/lfs-packages/10.1/coreutils-8.32.tar.xz
mwget http://mirror.jaleco.com/lfs/pub/lfs/lfs-packages/10.1/coreutils-8.32.tar.xz
tar -xvf coreutils-8.32.tar.xz
cd coreutils-8.32
./configure --prefix=/usr                     \
            --host=$LFS_TGT                   \
            --build=$(build-aux/config.guess) \
            --enable-install-program=hostname \
            --enable-no-install-program=kill,uptime \
            --disable-nls --disable-doc     \
 	    FORCE_UNSAFE_CONFIGURE=1
make
make DESTDIR=$LFS install
mv -v $LFS/usr/bin/{cat,chgrp,chmod,chown,cp,date,dd,df,echo} $LFS/bin
mv -v $LFS/usr/bin/{false,ln,ls,mkdir,mknod,mv,pwd,rm}        $LFS/bin
mv -v $LFS/usr/bin/{rmdir,stty,sync,true,uname}               $LFS/bin
mv -v $LFS/usr/bin/{head,nice,sleep,touch}                    $LFS/bin
mv -v $LFS/usr/bin/chroot                                     $LFS/usr/sbin
mkdir -pv $LFS/usr/share/man/man8
mv -v $LFS/usr/share/man/man1/chroot.1                        $LFS/usr/share/man/man8/chroot.8
sed -i 's/"1"/"8"/'                                           $LFS/usr/share/man/man8/chroot.8

sync
#install Bash
cd /jin/sources/10.1
#mwget ftp://ftp.osuosl.org/pub/lfs/lfs-packages/10.1/bash-5.1.tar.gz
mwget http://mirror.jaleco.com/lfs/pub/lfs/lfs-packages/10.1/bash-5.1.tar.gz
tar -xvf bash-5.1.tar.gz
cd bash-5.1
./configure --prefix=/usr                   \
            --build=$(support/config.guess) \
            --host=$LFS_TGT                 \
            --disable-nls --disable-doc     \
            --without-bash-malloc	        
make
make DESTDIR=$LFS install
mv $LFS/usr/bin/bash $LFS/bin/bash
ln -sv bash $LFS/bin/sh
sync
###preparing virtual kernel file system
mkdir -pv $LFS/{dev,proc,sys,run}
###7.5. Creating Directories
mkdir -pv $LFS/{boot,home,mnt,opt,srv}
mkdir -pv $LFS/etc/{opt,sysconfig}
mkdir -pv $LFS/lib/firmware
mkdir -pv $LFS/media/{floppy,cdrom}
mkdir -pv $LFS/usr/{,local/}{bin,include,lib,sbin,src}
mkdir -pv $LFS/usr/{,local/}share/{color,dict,doc,info,locale,man}
mkdir -pv $LFS/usr/{,local/}share/{misc,terminfo,zoneinfo}
mkdir -pv $LFS/usr/{,local/}share/man/man{1..8}
mkdir -pv $LFS/var/{cache,local,log,mail,opt,spool}
mkdir -pv $LFS/var/lib/{color,misc,locate}

ln -sfv /run $LFS/var/run
ln -sfv /run/lock $LFS/var/lock

install -dv -m 0750 $LFS/root
install -dv -m 1777 $LFS/tmp $LFS/var/tmp

#strip system
### delete the  dynamic lib won't be used
rm -rf `ls -a | grep -v "ld-2.33.so\|ld-linux-x86-64.so.2\|libc-2.33.so\|libc.so.6\|libdl-2.33.so\|libdl.so.2\|firmware\|modules`
rm -r $LFS/usr/lib/gconv
###
save_lib="ld-2.33.so libc-2.33.so libpthread-2.33.so libthread_db-1.0.so"

cd $LFS/lib

for LIB in $save_lib; do
    objcopy --only-keep-debug $LIB $LIB.dbg 
    strip --strip-unneeded $LIB
    objcopy --add-gnu-debuglink=$LIB.dbg $LIB 
done    

save_usrlib="libquadmath.so.0.0.0 libstdc++.so.6.0.28
             libitm.so.1.0.0 libatomic.so.1.2.0" 

cd $LFS/usr/lib

for LIB in $save_usrlib; do
    objcopy --only-keep-debug $LIB $LIB.dbg
    strip --strip-unneeded $LIB
    objcopy --add-gnu-debuglink=$LIB.dbg $LIB
done

unset LIB save_lib save_usrlib

find $LFS/usr/lib -type f -name \*.a \
   -exec strip --strip-debug {} ';'

find $LFS/lib $LFS/usr/lib -type f -name \*.so* ! -name \*dbg \
   -exec strip --strip-unneeded {} ';'

find $LFS/{bin,sbin} $LFS/usr/{bin,sbin,libexec} -type f \
    -exec strip --strip-all {} ';'


rm -r $LFS/usr/share/{automake*,aclocal*,autoconf,libtool}
rm -r $LFS/usr/bin/{make,automake*,aclocal*,autoconf,autom4te,autoheader}
rm -r $LFS/usr/bin/{autoreconf,autoscan,autoupdate,ifnamesi,libtool*}
rm -r $LFS/{,usr/}lib/{*.la,*.dbg}
rm -r $LFS/usr/lib/{crt*.o,?crt1.o,gcc-lib}
rm -r $LFS/lib/cpp
rm -r $LFS/usr/bin/{c++*,g++,cc,gcov,gcc*,cpp,i?86-pc-linux-{g++,c++,gcc*}}
rm -r $LFS/usr/include
rm -r $LFS/usr/lib/*.a
rm -r $LFS/usr/share/man
rm -r $LFS/usr/man
rm -r $LFS/usr/share/tex{info,mf}
rm -r $LFS/usr/share/groff
rm -r $LFS/usr/share/{doc,info}
rm -r $LFS/usr/share/{zoneinfo,locale}
rm -r $LFS/usr/lib/locale
rm -r $LFS/usr/share/i18n

#install linux
cd /jin/sources/10.1
cd linux-5.10.17
make defconfig
rm .config
cp /jin/scripts/config .config
make
make modules_install INSTALL_MOD_PATH=$LFS
cp -iv arch/x86/boot/bzImage $LFS/boot/vmlinuz-5.10.17-lfs-10.1
#cp -iv System.map $LFS/boot/System.map-5.10.17
#cp -iv .config $LFS/boot/config-5.10.17
sync
##9.6. System V Bootscript Usage and Configuration
###9.6.2. Configuring Sysvinit
cat > $LFS/etc/inittab << "EOF"
# Begin /etc/inittab

id:3:initdefault:

si::sysinit:/etc/rc.d/init.d/rc S

l0:0:wait:/etc/rc.d/init.d/rc 0
l1:S1:wait:/etc/rc.d/init.d/rc 1
l2:2:wait:/etc/rc.d/init.d/rc 2
l3:3:wait:/etc/rc.d/init.d/rc 3
l4:4:wait:/etc/rc.d/init.d/rc 4
l5:5:wait:/etc/rc.d/init.d/rc 5
l6:6:wait:/etc/rc.d/init.d/rc 6

ca:12345:ctrlaltdel:/sbin/shutdown -t1 -a -r now

su:S016:once:/sbin/sulogin

1:2345:respawn:/sbin/agetty --noclear tty1 9600
2:2345:respawn:/sbin/agetty tty2 9600
3:2345:respawn:/sbin/agetty tty3 9600
4:2345:respawn:/sbin/agetty tty4 9600
5:2345:respawn:/sbin/agetty tty5 9600
6:2345:respawn:/sbin/agetty tty6 9600

# End /etc/inittab
EOF
##9.6.4. Configuring the System Clock
cat > $LFS/etc/sysconfig/clock << "EOF"
# Begin /etc/sysconfig/clock

UTC=1

# Set this to any options you might need to give to hwclock,
# such as machine hardware clock type for Alphas.
CLOCKPARAMS=

# End /etc/sysconfig/clock
EOF
#9.6.5. Configuring the Linux Console
cat > $LFS/etc/sysconfig/console << "EOF"
# Begin /etc/sysconfig/console

KEYMAP="pl2"
FONT="lat2a-16 -m 8859-2"

# End /etc/sysconfig/console
EOF
##9.8. Creating the /etc/inputrc File
cat > $LFS/etc/inputrc << "EOF"
# Begin /etc/inputrc
# Modified by Chris Lynn <roryo@roryo.dynup.net>

# Allow the command prompt to wrap to the next line
set horizontal-scroll-mode Off

# Enable 8bit input
set meta-flag On
set input-meta On

# Turns off 8th bit stripping
set convert-meta Off

# Keep the 8th bit for display
set output-meta On

# none, visible or audible
set bell-style none

# All of the following map the escape sequence of the value
# contained in the 1st argument to the readline specific functions
"\eOd": backward-word
"\eOc": forward-word

# for linux console
"\e[1~": beginning-of-line
"\e[4~": end-of-line
"\e[5~": beginning-of-history
"\e[6~": end-of-history
"\e[3~": delete-char
"\e[2~": quoted-insert

# for xterm
"\eOH": beginning-of-line
"\eOF": end-of-line

# for Konsole
"\e[H": beginning-of-line
"\e[F": end-of-line

# End /etc/inputrc
EOF
##9.9. Creating the /etc/shells File
cat > $LFS/etc/shells << "EOF"
# Begin /etc/shells

/bin/sh
/bin/bash

# End /etc/shells
EOF
#10.2. Creating the /etc/fstab File
cat > $LFS/etc/fstab << "EOF"
# Begin /etc/fstab

# file system  mount-point  type     options             dump  fsck
#                                                              order

/dev/sda1      /            ext4     defaults            1     1
proc           /proc        proc     nosuid,noexec,nodev 0     0
sysfs          /sys         sysfs    nosuid,noexec,nodev 0     0
devpts         /dev/pts     devpts   gid=5,mode=620      0     0
tmpfs          /run         tmpfs    defaults            0     0
devtmpfs       /dev         devtmpfs mode=0755,nosuid    0     0

# End /etc/fstab
EOF
# umount lfs and swap dir
sync
#############
##config grub
grub-install --root-directory=$LFS  /dev/${NBD}
cat > $LFS/boot/grub/grub.cfg << "EOF"
# Begin /boot/grub/grub.cfg
set default=0
set timeout=5

insmod ext2
set root=(hd0,msdos1)

menuentry "GNU/Linux, Linux 5.10.17-lfs-10.1-systemd" {
        linux   /boot/vmlinuz-5.10.17-lfs-10.1 root=/dev/sda1 rw
}
EOF

############
##shrink filesystem
umount $LFS
e2fsck -f /dev/${NBD}p1
resize2fs -M /dev/${NBD}p1

##resize partition
fdisk /dev/$NBD << EOF
d

n
p
1

+70M
w
EOF

#check out the size of lfs partition
mount /dev/${NBD}p1 /mnt/lfs
df -h
##disconnect vdisk
umount $LFS
qemu-nbd -d /dev/$NBD
#shrink the vdisk
cd /jin/vdisk

qemu-img convert -p -f qcow2  -O raw lfs_10.1.qcow2 lfs_10.1.raw
qemu-img resize lfs_10.1.raw  -- -430M
qemu-img convert -p -f raw  -O vdi lfs_10.1.raw lfs_10.1.vdi
##end
