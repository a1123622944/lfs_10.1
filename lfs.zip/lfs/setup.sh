#!/bin/bash
docker build -t lfs .
docker run -it  --privileged  --name lfs_docker  -v/dev:/dev -v/lib/modules:/lib/modules:ro  lfs /bin/bash
docker cp lfs_docker:/jin/vdisk/lfs_10.1.vdi .
docker stop lfs_docker & docker rm lfs_docker
